<?php

namespace PleskExt\Skeleton;

class Helper
{
    public static function getTime(): int
    {
        return time();
    }
}
